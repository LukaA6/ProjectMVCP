<?php
$host = 'localhost';
$dbname = 'lm';      
$user = 'root';      
$pass = '';          

try {
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Database-connectie mislukt: " . $e->getMessage();
    exit;
}
