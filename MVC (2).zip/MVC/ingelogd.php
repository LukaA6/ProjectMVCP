<?php
session_start();

if (!isset($_SESSION['gebruiker'])) {
    header("Location: index.php");
    exit;
}

$gebruiker = $_SESSION['gebruiker'];
?>

<!DOCTYPE html>
<html lang="nl">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="styleinlog.css">
<title>Profiel bijwerken</title>
</head>
<body>
<div class="container">
    <h1>Welkom, Gebruiker!</h1>
    <p style="text-align:center; color:#666;">Je bent succesvol ingelogd.</p>

    <h2>Profiel bijwerken</h2>
    <form>
        <label for="naam">Naam:</label>
        <input type="text" id="naam" name="naam" placeholder="Voer je naam in" required />

        <label for="email">E-mailadres:</label>
        <input type="email" id="email" name="email" placeholder="Voer je e-mailadres in" required />

        <label for="wachtwoord">Nieuw wachtwoord:</label>
        <input type="password" id="wachtwoord" name="wachtwoord" placeholder="Laat leeg om niet te wijzigen" />

        <label for="pfp">Profielfoto:</label>
        <input type="file" id="pfp" name="pfp" accept="image/*" />
        <img src="https://via.placeholder.com/80" alt="Voorbeeld profielfoto" class="thumb" />

        <button type="submit">Opslaan</button>
    </form>

    <form action="uitloggen.php" method="post" class="logout-form">
        <button type="submit">Uitloggen</button>
    </form>
</div>
</body>
</html>
