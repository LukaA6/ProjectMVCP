<?php
session_start();

if (isset($_SESSION['melding'])) {
    $melding = $_SESSION['melding'];
    unset($_SESSION['melding']);
} else {
    $melding = null;
}

$producten = [
    1 => ["naam" => "Offwhite Green", "prijs" => 399.99, "afbeelding" => "images/product1.jpg"],
    2 => ["naam" => "Offwhite Red", "prijs" => 329.99, "afbeelding" => "images/product2.jpg"],
    3 => ["naam" => "Offwhite Black", "prijs" => 489.99, "afbeelding" => "images/product3.jpg"],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['toevoegen'])) {
        $id = (int)$_POST['id'];
        if (isset($producten[$id])) {
            $_SESSION['mandje'][] = $id;
        }
    }

    if (isset($_POST['verwijderen'])) {
        $index = (int)$_POST['index'];
        if (isset($_SESSION['mandje'][$index])) {
            unset($_SESSION['mandje'][$index]);
            $_SESSION['mandje'] = array_values($_SESSION['mandje']);
        }
    }
}

$mandje = $_SESSION['mandje'] ?? [];
$totaal = array_reduce($mandje, fn($carry, $id) => $carry + $producten[$id]['prijs'], 0);
?>

<!DOCTYPE html>
<html lang="nl">
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="styleindex.css">
<title>Webshop</title>
</head>
<body>

<?php if ($melding): ?>
    <div class="melding"><?= htmlspecialchars($melding) ?></div>
<?php endif; ?>

<header>
    <div class="container header-content">
        <h1>🛒 KlikKlaar</h1>
        <div>
            <button class="auth-btn login" id="openLoginBtn">Inloggen</button>
            <button class="auth-btn register" id="openRegisterBtn">Registreren</button>
            <button class="cart-icon" onclick="toggleCart()">
                🛒 <span id="cart-count"><?= count($mandje) ?></span>
            </button>
        </div>
    </div>
</header>


<div id="cartOverlay" class="cart-overlay" onclick="toggleCart()">
    <div class="cart-popup" onclick="event.stopPropagation()">
        <h2>Winkelmandje (<?= count($mandje) ?>)</h2>
        <?php if (!$mandje): ?>
            <p>Je mandje is leeg.</p>
        <?php else: ?>
            <ul>
                <?php foreach ($mandje as $index => $id): ?>
                    <?php $p = $producten[$id]; ?>
                    <li>
                        <?= htmlspecialchars($p['naam']) ?>
                        <form method="post">
                            <input type="hidden" name="index" value="<?= $index ?>">
                            <button type="submit" name="verwijderen">&times;</button>
                        </form>
                    </li>
                <?php endforeach; ?>
            </ul>
            <p><strong>Totaal:</strong> €<?= number_format($totaal, 2, ',', '.') ?></p>
        <?php endif; ?>
    </div>
</div>


<div id="registerPopup" class="popup-overlay">
    <div class="popup-content">
        <button class="close-btn" id="closeRegisterBtn">&times;</button>
        <h2>Registreren</h2>
        <form action="registreren_verwerken.php" method="post">
            <input type="text" name="naam" placeholder="Naam" required>
            <input type="email" name="email" placeholder="E-mail" required>
            <input type="password" name="wachtwoord" placeholder="Wachtwoord" required>
            <button type="submit" class="submit-btn">Registreren</button>
        </form>
    </div>
</div>


<div id="loginPopup" class="popup-overlay">
    <div class="popup-content">
        <button class="close-btn" id="closeLoginBtn">&times;</button>
        <h2>Inloggen</h2>
        <form action="inloggen_verwerken.php" method="post">
            <input type="email" name="email" placeholder="E-mail" required>
            <input type="password" name="wachtwoord" placeholder="Wachtwoord" required>
            <button type="submit" class="submit-btn">Inloggen</button>
        </form>
    </div>
</div>

<main class="container">
    <div class="product-grid">
        <?php foreach ($producten as $id => $p): ?>
            <div class="product-card">
                <img src="<?= htmlspecialchars($p['afbeelding']) ?>" alt="<?= htmlspecialchars($p['naam']) ?>">
                <div class="info">
                    <h2><?= htmlspecialchars($p['naam']) ?></h2>
                    <p class="price">€<?= number_format($p['prijs'], 2, ',', '.') ?></p>
                    <form method="post">
                        <input type="hidden" name="id" value="<?= $id ?>">
                        <button type="submit" name="toevoegen">Toevoegen</button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</main>

<script>
function toggleCart() {
    document.getElementById('cartOverlay').classList.toggle('active');
}

document.getElementById('openRegisterBtn').addEventListener('click', () => {
    document.getElementById('registerPopup').classList.add('active');
});
document.getElementById('closeRegisterBtn').addEventListener('click', () => {
    document.getElementById('registerPopup').classList.remove('active');
});
document.getElementById('registerPopup').addEventListener('click', e => {
    if (e.target === e.currentTarget) e.currentTarget.classList.remove('active');
});

document.getElementById('openLoginBtn').addEventListener('click', () => {
    document.getElementById('loginPopup').classList.add('active');
});
document.getElementById('closeLoginBtn').addEventListener('click', () => {
    document.getElementById('loginPopup').classList.remove('active');
});
document.getElementById('loginPopup').addEventListener('click', e => {
    if (e.target === e.currentTarget) e.currentTarget.classList.remove('active');
});
</script>

</body>
</html>
